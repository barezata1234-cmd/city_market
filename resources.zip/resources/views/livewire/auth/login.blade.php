<div class="w-full max-w-md">
    <div id="offline-banner" style="display: none;" class="fixed top-0 left-0 w-full bg-red-600 text-white text-center py-2.5 z-50 font-bold text-sm shadow-md">
        ⚠️ تۆ ئێستا لە دۆخی ئۆفلاین دایت! سیستەمەکە لۆکاڵی کار دەکات.
    </div>

    <div class="bg-white rounded-3xl shadow-2xl w-full p-8 md:p-10 border border-gray-100">
     
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-50 mb-4 shadow-inner">
                <svg class="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                </svg>
            </div>
            
            <h1 id="login-title" class="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-l from-indigo-600 to-blue-500 mb-2">
                ماركێتی شارەکەم
            </h1>
            <p id="login-desc" class="text-sm text-gray-500 font-medium">بەخێربێیتەوە! تکایە بچۆ ژوورەوە بۆ بەڕێوەبردنی سیستەم</p>
        </div>

        <div id="error-container" class="{{ $errors->any() ? '' : 'hidden' }} bg-red-50 border-r-4 border-red-500 text-red-700 px-4 py-3 rounded-lg text-sm mb-6 flex items-center shadow-sm">
            <svg class="w-5 h-5 ml-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span id="error-text">
                @if($errors->has('email')) {{ $errors->first('email') }} @endif
                @if($errors->has('password')) {{ $errors->first('password') }} @endif
            </span>
        </div>

        <form id="login-form" wire:submit.prevent="login" class="space-y-5">
            
            <div class="space-y-1.5">
                <label class="block text-sm font-semibold text-gray-700">ئیمەیل</label>
                <input type="email" id="email" wire:model.defer="email" required autofocus
                       class="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200 outline-none bg-gray-50 focus:bg-white placeholder-gray-400"
                       placeholder="ئیمەیلەکەت بنووسە...">
            </div>

            <div class="space-y-1.5">
                <label class="block text-sm font-semibold text-gray-700">وشەی نهێنی</label>
                <input type="password" id="password" wire:model.defer="password" required
                       class="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200 outline-none bg-gray-50 focus:bg-white placeholder-gray-400"
                       placeholder="••••••••">
            </div>

            <div class="flex items-center justify-between pt-1">
                <label class="flex items-center gap-2 cursor-pointer group">
                    <input type="checkbox" wire:model="remember" 
                           class="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500 cursor-pointer">
                    <span class="text-sm text-gray-600 group-hover:text-indigo-700 transition-colors">بمهێڵەوە چوونەژوورەوە</span>
                </label>
                
                <a href="{{ route('password.request') }}" class="text-sm font-medium text-indigo-600 hover:text-indigo-800 transition-colors">
                    وشەی نهێنیت لەبیرکردووە؟
                </a>
            </div>

            <button type="submit" id="submit-btn" class="w-full bg-gradient-to-r from-indigo-600 to-blue-500 hover:from-indigo-700 hover:to-blue-600 text-white rounded-xl py-3.5 text-sm font-bold shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200 mt-2">
                چوونەژوورەوە
            </button>
        </form>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bcryptjs/2.4.3/bcrypt.min.js"></script>
    <script>
        let offlineUsers = {!! json_encode($offlineUsers) !!};
        let isReallyOnline = navigator.onLine;

        function syncOfflineUsersCache() {
            if (isReallyOnline && offlineUsers.length > 0) {
                localStorage.setItem('offline_users', JSON.stringify(offlineUsers));
            } else if (!isReallyOnline) {
                const localData = localStorage.getItem('offline_users');
                offlineUsers = localData ? JSON.parse(localData) : offlineUsers;
            }
        }

        async function checkConnectivity() {
            try {
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 3000);
                const res = await fetch('/ping', { method: 'GET', cache: 'no-store', signal: controller.signal });
                clearTimeout(timeoutId);
                isReallyOnline = res.ok;
            } catch (e) {
                isReallyOnline = false;
            }
            syncOfflineUsersCache();
            updateConnectionStatus();
        }

        function updateConnectionStatus() {
            const banner = document.getElementById('offline-banner');
            const title = document.getElementById('login-title');
            const desc = document.getElementById('login-desc');
            const btn = document.getElementById('submit-btn');

            if (isReallyOnline) {
                banner.style.display = 'none';
                title.innerText = "ماركێتی شارەکەم";
                title.className = "text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-l from-indigo-600 to-blue-500 mb-2";
                desc.innerText = "بەخێربێیتەوە! تکایە بچۆ ژوورەوە بۆ بەڕێوەبردنی سیستەم";
                btn.className = "w-full bg-gradient-to-r from-indigo-600 to-blue-500 hover:from-indigo-700 hover:to-blue-600 text-white rounded-xl py-3.5 text-sm font-bold shadow-lg transform hover:-translate-y-0.5 transition-all duration-200 mt-2";
            } else {
                banner.style.display = 'block';
                title.innerText = "چوونەژوورەوە بۆ Offline";
                title.className = "text-3xl font-bold text-red-600 mb-2";
                desc.innerText = "تەنها ئەو بەکارهێنەرانەی مۆڵەتنراون دەتوانن بچنە ژوورەوە";
                btn.className = "w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white rounded-xl py-3.5 text-sm font-bold shadow-lg transform hover:-translate-y-0.5 transition-all duration-200 mt-2";
            }
        }

        document.getElementById('login-form').addEventListener('submit', function(e) {
            if (!isReallyOnline) {
                e.preventDefault(); 

                const emailInput = document.getElementById('email').value.trim();
                const passwordInput = document.getElementById('password').value;
                const errorContainer = document.getElementById('error-container');
                const errorText = document.getElementById('error-text');

                const user = offlineUsers.find(u => u.email === emailInput);
                const bcryptLib = window.bcrypt || (window.dcodeIO && window.dcodeIO.bcrypt);
                
                let matches = false;
                if (user && bcryptLib) {
                    try {
                        matches = bcryptLib.compareSync(passwordInput, user.password);
                    } catch(err) {
                        console.error("Bcrypt Error:", err);
                    }
                }

                if (matches) {
                    errorContainer.classList.add('hidden');
                    
                    // پاشەکەوتکردنی زانیاری کاشێری لۆکاڵ
                    localStorage.setItem('current_offline_user', JSON.stringify({ email: user.email, name: user.name }));
                    
                    // 🚀 ئاراستەکردنی ڕاستەوخۆ بۆ سەر شاشەی فرۆشتن لە کاتی ئۆفلایندا
                    window.location.href = "{{ route('sales.create') }}"; 
                } else {
                    errorText.innerText = "ئیمەیڵ یان وشەی نهێنی دەستنیشانکراو هەڵەیە!";
                    errorContainer.classList.remove('hidden');
                }
            }
        });

        window.addEventListener('online', checkConnectivity);
        window.addEventListener('offline', checkConnectivity);
        document.addEventListener("DOMContentLoaded", checkConnectivity);
        setInterval(checkConnectivity, 5000);
    </script>
</div>